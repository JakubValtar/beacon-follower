/**
 * Low-level access to Linux features
 */
package lejos.internal.io;