/**
 * Interface to the DBus subsystem, used for Bluetooth support.
 */
package lejos.internal.dbus;