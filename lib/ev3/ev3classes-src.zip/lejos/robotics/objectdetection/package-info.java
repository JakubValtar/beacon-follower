/**
 * Object detection classes.
 */
package lejos.robotics.objectdetection;
