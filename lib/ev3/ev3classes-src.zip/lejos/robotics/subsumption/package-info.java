/**
 * Support for subsumption architecture.
 */
package lejos.robotics.subsumption;
