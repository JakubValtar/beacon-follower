package lejos.hardware;

/**
 * Interface for calling calling lejos listeners.
 */
public interface ListenerCaller {
  int callListeners();
}

