/**
 * Access to all the sensors that are supported on the EV3. 
 * 
 * Devices that are not strictly sensors are in lejos.hardwae.devie.
 * 
 */
package lejos.hardware.sensor;
