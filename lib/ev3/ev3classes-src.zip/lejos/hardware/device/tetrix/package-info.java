/**
 * <p>
 * HiTechnic Tetrix Motor and Servo controller support.
 * </p><p>
 * For unit details, see:
 * <br/><a href="http://www.legoeducation.us/eng/product/hitechnic_dc_motor_controller/1648">
 * http://www.legoeducation.us/eng/product/hitechnic_dc_motor_controller/1648
 * </a>
 * <br/>
 * <a href="http://www.legoeducation.us/eng/product/hitechnic_servo_controller/1649">
 * http://www.legoeducation.us/eng/product/hitechnic_servo_controller/1649
 * </a>
 * </p>
 */
package lejos.hardware.device.tetrix;
